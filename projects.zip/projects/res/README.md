# Railway-Reservation-System

Requirements-Python 3.5.2,Django 2.0.2

It is a Simple Railway Reservation System that allows User to Search Trains,Book Tickets,Cancel tickets,Check Train Schedule and Check PNR.

It also has Admin side which allows extra features like Add Routes,Stations,Trains.

Login Credentials
Admin Side :    Uid-'tushar'       Pass-'pass1234' 

Normal User:    Uid:'pritam'       Pass-'pritam123'
 
Use Port 8500
